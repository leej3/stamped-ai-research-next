# STAMPED alignment assessment — 2026-10-15

**Verdict:** MUST 16 met / 1 partial / 0 unmet / 0 not-checked; SHOULD 3 met / 3 partial / 2 unmet / 1 not-applicable / 0 not-checked; MAY 4 met / 1 partial / 0 unmet / 0 not-checked. A partial does not satisfy a MUST.

**Object:** `git@github.com:leej3/stamped-ai-research-next.git`, committed state `8b5bcdaa999289a47f066ba829511d450301c573`; checklist 0.3.1. Probe run included remote checks. The working tree was clean. The linked skills module did not resolve at its pin during probe checks. A same-host fresh checkout and locked Pixi replay subsequently regenerated all 15 result artifacts byte-for-byte; this establishes replay on that host, not publication of this assessed revision.

## Goals and kind

**Assumption, not confirmed:** Based on the user's request and project documentation, this is a computational study that tests a group-level fMRI hypothesis and ships code, results, and a concise scientific report. The study goal and kind were not separately confirmed.

## What to address first

1. Publish the assessed commit and its annex content at a retrievable remote. The configured remotes respond, but advertise only `main`; neither advertises commit `8b5bcdaa999289a47f066ba829511d450301c573`. This leaves MUST 016 partial.
2. Add a CI route that checks documented setup and execution, including regular locked-environment rebuilds (SHOULD 002 and 006).
3. Consider running analyses in a disposable environment per run. Current Pixi tasks use the root environment (SHOULD 005).

## What is already in place

The project keeps the 54 participant maps in git-annex under the project root, tracks a Pixi manifest and lockfile, separates inputs, scripts, and results, and documents the analysis route. The recorded duct run links code, environment, inputs, outputs, and resource summary. A fresh same-host checkout replayed the result artifacts byte-for-byte. The independent result validation is also included in the executable workflow.

## Per-item findings

| item | principles | status | source | evidence | reason |
|---|---|---|---|---|---|
| must/001 | S.1 | met | judgement | `README.md`, `input/data/sub-001_hypo1_cope.nii.gz`, `.gitmodules` | All essential study files are nested under the committed root; inputs, code, results, environment and linked skills are reachable from it. |
| must/002 | S.1 | met | probe:subdatasets-resolvable+judgement | `input/sources.json`, `input/data/sub-001_hypo1_cope.nii.gz`, `logs/replay-compare-final-20261015-stdout` | The 54 maps are annexed under input/data and source metadata is in input; the probe's unresolved skills pin is not a dataset. |
| must/003 | S.1 | met | judgement | `pixi.toml`, `scripts/analyze.py`, `scripts/validate_results.py`, `scripts/write_run_record.py`, `.gitmodules` | All analysis imports and runtime tools are declared in Pixi; the related workflow skills are linked as a root submodule. |
| must/004 | T.1,T.3,T.5 | met | probe:tree-clean | `git ls-files`, `git status --porcelain` | git tracks 43 text, code and configuration file(s), and `git status` is empty including submodules: the committed state is the whole state. |
| must/005 | T.1,T.3,T.5 | met | probe:large-in-annex | `git ls-tree -r -l HEAD`, `.datalad/config` | git-annex carries the binary content (60 pointer(s) tracked) and no binary blob over 10 MiB is in git. |
| must/006 | T.1,T.3,T.5 | met | probe:derived-have-records+judgement | `logs/20261015T233701Z-provenance.json`, `logs/20261015T233701Z-analysis-info.json`, `scripts/run_recorded_analysis.sh` | The recorded run links code, Pixi manifest/lock hashes, supplied input hashes, output hashes and a completed duct summary. |
| must/007 | A.1 | met | probe:entry-point | `README.md`, `scripts/analyze.py`, `scripts/run_recorded_analysis.sh`, `scripts/validate_results.py` | README.md has an install/usage/reproduce section. |
| must/008 | A.1 | met | probe:entry-point | `README.md`, `scripts/analyze.py`, `scripts/run_recorded_analysis.sh`, `scripts/validate_results.py` | Starting point present: scripts/analyze.py. |
| must/009 | P.1 | met | probe:no-abs-paths | `probe:no-abs-paths` | No host-specific absolute paths in tracked text files. |
| must/010 | P.1 | met | judgement | `pixi.toml`, `scripts/analyze.py`, `scripts/validate_results.py`, `scripts/write_run_record.py`, `README.md` | All nonstandard imports and runtime commands are declared in Pixi; Git and Pixi bootstrap requirements are documented. |
| must/011 | P.1 | met | judgement | `README.md`, `pixi.toml`, `scripts/run_recorded_analysis.sh` | README documents Git/Pixi prerequisites and supported platforms; the workflows require no other host service or hardware. |
| must/012 | P.2 | met | judgement | `README.md`, `pixi.toml`, `pixi.lock` | README lists system prerequisites and platforms; pixi.toml and the tracked lock specify software dependencies. |
| must/013 | P.3 | met | probe:env-spec-tracked | `pixi.lock`, `pixi.toml` | Tracked: pixi.lock, pixi.toml. |
| must/014 | P.3 | met | judgement | `README.md`, `pixi.toml`, `pixi.lock`, `2ea9577` | README documents dependency updates with pixi add/remove and committing the manifest plus lock; both files are tracked. |
| must/015 | D.1 | met | probe:run-env-linked+judgement | `pixi.lock`, `logs/20261015T233701Z-provenance.json`, `logs/replay-compare-final-20261015-stdout` | The tracked lock pins package versions, and the recorded run stores its SHA-256 and package versions. |
| must/016 | D.1 | partial ⚠ (a MUST is not satisfied by partial) | probe:env-spec-tracked+judgement | `/tmp/narps-stamped-assessment-20261015/remote-status.txt`, `git:8b5bcdaa999289a47f066ba829511d450301c573` | Remotes respond, but only main is advertised; the assessed revision is not published, so others cannot yet retrieve this exact state. |
| must/017 | D.1 | met | judgement | `README.md`, `pixi.toml`, `pixi.lock` | README links Pixi installation instructions and gives the locked install and run commands. |
| should/001 | T.2 | met | judgement | `.gitmodules`, `input/data/sub-001_hypo1_cope.nii.gz`, `git:8b5bcdaa999289a47f066ba829511d450301c573` | Git versions code, text, environment and results; git-annex carries the participant maps, and the skills component is a Git submodule. |
| should/002 | A.2 | unmet | probe:ci-present | `probe:ci-present` | No CI configuration: nothing checks that the instructions still work. |
| should/003 | M.1 | met | probe:modules-separated+probe:inputs-untouched+judgement | `README.md`, `input/`, `scripts/`, `results/`, `pixi.toml` | Inputs, code, results and environment occupy separate paths; the skills submodule commit is upstream content, not a study-derived product. |
| should/004 | E.1 | partial | judgement | `logs/replay-compare-final-20261015-stdout`, `logs/20261015T233747Z-analysis-info.json`, `logs/replay-pilot-final-20261015-info.json` | A fresh checkout and Pixi environment reproduced all outputs on the same host; no isolated container, VM or cloud run was made. |
| should/005 | E.1 | unmet | judgement | `pixi.toml`, `README.md` | Each analysis reuses the root Pixi environment; the recorded task creates per-run logs but not a disposable environment. |
| should/006 | D.2 | partial | probe:ci-present+judgement | `logs/replay-compare-final-20261015-stdout`, `pixi.lock`, `probe:ci-present` | The exact lock was restored and replayed once in a fresh checkout, but no CI or recurring environment rebuild is configured. |
| should/007 | D.2 | partial | judgement | `pixi.toml`, `pixi.lock`, `README.md` | The object archives the manifest and lock but not package binaries or a container image; rebuild depends on configured package channels. |
| should/008 | D.2 | met | judgement | `README.md`, `pixi.toml`, `pixi.lock` | Duplicate of must/014: the Pixi update process and tracked manifest/lock are documented and present. |
| should/009 | M.4 | not-applicable | judgement | `input/sources.json`, `pixi.toml` | N/A: the supplied NARPS maps and software are public; this study contains no restricted component to isolate. |
| may/001 | M.2 | met | probe:subdatasets-resolvable | `.gitmodules` | 1 external component(s) are linked as modules: skills |
| may/002 | M.2 | met | judgement | `README.md`, `analysis-protocol.md` | README explains the input, code, results and environment paths and links the protocol and scientific report. |
| may/003 | M.2 | partial | judgement | `README.md`, `pixi.toml`, `git:8b5bcdaa999289a47f066ba829511d450301c573` | Directory and task boundaries permit separate file updates, but all components share one Git history and release lifecycle. |
| may/004 | M.2 | met | judgement | `pixi.toml`, `scripts/run_recorded_analysis.sh` | Pixi tasks compose the declared environment with the analysis, validation and recorded-run scripts. |
| may/005 | M.2 | met | judgement | `README.md`, `analysis-protocol.md`, `results/report.md` | README and protocol describe project paths, reproduction commands and scientific scope. |

## Flagged items

- **MUST 002:** The automated subdataset probe concerns the linked skills module rather than the cohort data; the 54 maps are annexed in `input/data` and were retrieved in the fresh checkout replay. The verdict was overridden and the probe mapping questioned.
- **MUST 006:** The derived-file probe missed the recorded duct provenance chain; the run record and analysis summary provide the evidence. The verdict was overridden.
- **MUST 015:** The environment linkage probe missed the tracked lock hash and package details in the provenance record. The verdict was overridden.
- **SHOULD 003:** The inputs-untouched probe conflates upstream skill-module state with study-derived products. Study inputs, code, outputs, and environment are separated by directory. The verdict was overridden and the mapping questioned.
- **SHOULD 008:** This duplicates MUST 014 in the pinned checklist; both are answered from the same dependency-update process evidence.

## Not checked

None. No item is marked not-checked. SHOULD 009 is not-applicable because the study uses public inputs and software and has no restricted component to isolate.

## Assessment files and provenance

- Response: [`2026-10-15-response.json`](2026-10-15-response.json)
- Probe results: [`2026-10-15-probes.json`](2026-10-15-probes.json)
- Checklist app URL: [`2026-10-15-url.txt`](2026-10-15-url.txt)
- Remote probe details: [`remote-status.txt`](remote-status.txt)

The response passed schema/checklist validation: 31 answers against checklist 0.3.1. Harness and model were recorded as Codex CLI and `gpt-6-luna`; conventions dependency `stamped-conventions@0.1.0`. Assessment scope is the committed state named above. The URL is kept in its own file because it is lengthy.
